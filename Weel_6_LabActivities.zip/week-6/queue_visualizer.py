import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
HORIZONTAL_GAP = 10
CANVAS_WIDTH = 600
CANVAS_HEIGHT = 200

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = []

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="In Value:").grid(row=0, column=0)
        self.in_entry = tk.Entry(control_frame, width=10)
        self.in_entry.grid(row=0, column=1)

        in_btn = tk.Button(control_frame, text="In", command=self.enqueue_value)
        in_btn.grid(row=0, column=2, padx=5)

        out_btn = tk.Button(control_frame, text="Out", command=self.dequeue_value)
        out_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(
            x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
            fill="lightblue", outline="black", width=2
        )
        self.canvas.create_text(
            x + NODE_WIDTH / 2,
            y + NODE_HEIGHT / 2,
            text=str(data),
            font=("Arial", 16)
        )

    def draw_queue(self):
        self.canvas.delete("all")

        x = 20
        y = (CANVAS_HEIGHT - NODE_HEIGHT) // 2

        for val in self.queue:
            self.draw_node(x, y, val)
            x += NODE_WIDTH + HORIZONTAL_GAP

        # Labels
        if self.queue:
            self.canvas.create_text(20, y - 20, text="Front", fill="red", font=("Arial", 12), anchor="w")
            self.canvas.create_text(x - NODE_WIDTH, y + NODE_HEIGHT + 15, text="Rear", fill="blue", font=("Arial", 12))

    def enqueue_value(self):
        try:
            val = int(self.in_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Enter an integer.")
            return

        self.queue.append(val)  # add to rear
        self.in_entry.delete(0, tk.END)
        self.status_label.config(text=f"{val} in")
        self.draw_queue()

    def dequeue_value(self):
        if len(self.queue) == 0:
            messagebox.showinfo("Empty Queue", "Queue is empty.")
            return

        val = self.queue.pop(0)  # remove from front
        self.status_label.config(text=f"{val} out")
        self.draw_queue()


if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)

    # Example preload
    # app.queue = [10, 20, 30]
    # app.draw_queue()

    root.mainloop()