import random
import timeit

def linear_search(array, target):

    for i in range(len(array)):
        if array[i] == target:
            return i
        
    return -1

# test = range(10000)
# print(linear_search(test, 100))
# print(linear_search(test, -999))


def binary_search(array, target):

    # Initialize 'pointers'
    left = 0
    right = len(array) - 1 # Account for indexing to get the right most element index
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target: # If target is found 
            return mid
        elif target > array[mid]:
            left = mid + 1 # We already checked the mid element, so we shift the index by 1 for the next search.
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right)/2) # Recalculate mid

    return -1

# test = range(10000)
# print(binary_search(test, 1))
# print(binary_search(test, -2))

# Test Cases
sorted_list = list(range(100000))
target = random.randint(0,999)  # Random target value
linear_time = timeit.timeit(lambda: linear_search(sorted_list, target), number=100)
binary_time = timeit.timeit(lambda: binary_search(sorted_list, target), number=100)

print(f"Linear search execution time: {linear_time:.6f} seconds")
print(f"Binary search execution time: {binary_time:.6f} seconds")