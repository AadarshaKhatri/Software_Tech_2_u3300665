import random
import timeit

def bubble_sort(arr):
    # Get the length of the input list
    n = len(arr)

    # Traverse through all elements in the list
    for i in range(n):

        # Flag to optimize the algorithm
        # If no swaps are performed in an iteration, the list is already sorted, and we can stop early
        swapped = False

        # Last i elements are already in place, so we don't need to compare them again
        for j in range(0, n - i - 1):

            # Compare adjacent elements
            if arr[j] > arr[j + 1]:

                # Swap if the element found is greater than the next element
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

                # Set the swapped flag to True to indicate that a swap occurred in this iteration
                swapped = True

        # If no two elements were swapped in the inner loop, the list is sorted, and we can exit early
        if not swapped:
            break

    return arr


def insertion_sort(arr):
   

    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element

    return arr

def linear_search(array, target):

    for i in range(len(array)):
        if array[i] == target:
            return i
        
    return -1



def binary_search(array, target):

    # Initialize 'pointers'
    left = 0
    right = len(array) - 1 # Account for indexing to get the right most element index
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target: # If target is found 
            return mid
        elif target > array[mid]:
            left = mid + 1 # We already checked the mid element, so we shift the index by 1 for the next search.
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right)/2) # Recalculate mid

    return -1


def insertion_linear_serach(array, target):
    array = insertion_sort(array)
    result = linear_search(array, target)
    return result

def insertion_binary_search(array,target):
    array = insertion_sort(array)
    result = binary_search(array,target)
    return result

def bubble_linear_serach(array, target):
    array = bubble_sort(array)
    result = linear_search(array, target)
    return result

def bubble_binary_search(array,target):
    array = bubble_sort(array)
    result = binary_search(array,target)
    return result

unsorted_list = [random.randint(1, 1000) for n in range(10000)]
target = random.randint(1, 100)
binary_time_i = timeit.timeit(lambda: insertion_binary_search(unsorted_list, target), number=1)

unsorted_list = [random.randint(1, 1000) for n in range(10000)]
target = random.randint(1, 100)
linear_time_i = timeit.timeit(lambda: insertion_linear_serach(unsorted_list, target), number=1)

unsorted_list = [random.randint(1, 1000) for n in range(100000)]
target = random.randint(1, 100)
binary_time_b = timeit.timeit(lambda: bubble_binary_search(unsorted_list, target), number=1)

unsorted_list = [random.randint(1, 1000) for n in range(10000)]
target = random.randint(1, 100)
linear_time_b = timeit.timeit(lambda: bubble_linear_serach(unsorted_list, target), number=1)


print(f"Binary Search (With Insertion): {binary_time_i:.6f} seconds")
print(f"Binary Search (With Bubble): {binary_time_b:.6f} seconds")
print()
print(f"Linear Search (With Insertion): {linear_time_i:.6f} seconds")
print(f"Linear Search (With Bubble): {linear_time_b:.6f} seconds")