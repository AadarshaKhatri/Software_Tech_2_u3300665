import random 
import timeit

def bubble_sort(arr):
    # Get the length of the input list
    n = len(arr)

    # Traverse through all elements in the list
    for i in range(n):

        # Flag to optimize the algorithm
        # If no swaps are performed in an iteration, the list is already sorted, and we can stop early
        swapped = False

        # Last i elements are already in place, so we don't need to compare them again
        for j in range(0, n - i - 1):

            # Compare adjacent elements
            if arr[j] > arr[j + 1]:

                # Swap if the element found is greater than the next element
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

                # Set the swapped flag to True to indicate that a swap occurred in this iteration
                swapped = True

        # If no two elements were swapped in the inner loop, the list is sorted, and we can exit early
        if not swapped:
            break

    return arr




def insertion_sort(arr):
   

    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element

    return arr



# unsorted_list = [64, 25, 12, 22, 11]
# print("Original Array for Bubble : ", unsorted_list)
# sorted_list_bubble = bubble_sort(unsorted_list)
# print("Sorted array for buble:", sorted_list_bubble)
# print()


# unsorted_list = [64, 1, 12, 22, 11]
# print("Orginal Array for Insertion",unsorted_list)
# sorted_list = insertion_sort(unsorted_list)
# print("Sorted array for Insertion:", sorted_list)

# Test case
unsorted_list = [random.randint(1, 1000) for _ in range(10000)]

# Measure and compare the runtimes of Bubble Sort and Insertion Sort
bubble_sort_time = timeit.timeit(lambda: bubble_sort(unsorted_list.copy()), number=1)
insertion_sort_time = timeit.timeit(lambda: insertion_sort(unsorted_list.copy()), number=1)

print(f"Bubble Sort Execution Time: {bubble_sort_time:.6f} seconds")
print(f"Insertion Sort Execution Time: {insertion_sort_time:.6f} seconds")

print(unsorted_list)