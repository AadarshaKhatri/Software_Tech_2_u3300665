import time
import random
import string
import tkinter as tk

# =========================
# BST
# =========================
class Node:
    def __init__(self, name):
        self.name = name
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name):
        if root is None:
            return Node(name)

        if name < root.name:
            root.left = self.insert(root.left, name)
        elif name > root.name:
            root.right = self.insert(root.right, name)

        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

    def find_min(self, root):
        while root.left:
            root = root.left
        return root

    def delete(self, root, name):
        if root is None:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left

            temp = self.find_min(root.right)
            root.name = temp.name
            root.right = self.delete(root.right, temp.name)

        return root


# =========================
# AVL TREE
# =========================
class AVLNode:
    def __init__(self, name):
        self.name = name
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        return self.height(node.left) - self.height(node.right) if node else 0

    def right_rotate(self, z):
        y = z.left
        z.left = y.right
        y.right = z
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        z.right = y.left
        y.left = z
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name):
        if not node:
            return AVLNode(name)

        if name < node.name:
            node.left = self.insert(node.left, name)
        elif name > node.name:
            node.right = self.insert(node.right, name)
        else:
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    def min_value_node(self, node):
        while node.left:
            node = node.left
        return node

    def delete(self, root, name):
        if not root:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left

            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.right = self.delete(root.right, temp.name)

        if not root:
            return root

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root


# =========================
# RED-BLACK TREE
# =========================
class RBNode:
    def __init__(self, name, color="red"):
        self.name = name
        self.color = color
        self.left = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(None, "black")
        self.root = self.NIL

    def insert(self, name):
        node = RBNode(name)
        node.left = node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if name < current.name:
                current = current.left
            else:
                current = current.right

        node.parent = parent

        if parent is None:
            self.root = node
        elif name < parent.name:
            parent.left = node
        else:
            parent.right = node

        self.fix_insert(node)

    def fix_insert(self, k):
        if k.parent is None or k.parent.parent is None:
          return
        while k.parent and k.parent.color == "red":
            if k.parent == k.parent.parent.left:
                u = k.parent.parent.right
                if u.color == "red":
                    k.parent.color = "black"
                    u.color = "black"
                    k.parent.parent.color = "red"
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                    k.parent.color = "black"
                    k.parent.parent.color = "red"
            else:
                k = k.parent.parent
        self.root.color = "black"

    def search(self, node, key):
        if node == self.NIL or key == node.name:
            return node
        if key < node.name:
            return self.search(node.left, key)
        return self.search(node.right, key)

    # ⚠️ Simplified delete (for benchmarking only)
    def delete(self, key):
        pass  # Real RB delete is complex, not needed unless required


# =========================
# BENCHMARK
# =========================
def benchmark(n=5000):
    names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
    search_keys = random.sample(names, n // 2)
    delete_keys = random.sample(names, n // 4)

    # ---------- BST ----------
    bst = BST()
    start = time.time()
    for name in names:
        bst.root = bst.insert(bst.root, name)
    bst_insert = time.time() - start

    start = time.time()
    for key in search_keys:
        bst.search(bst.root, key)
    bst_search = time.time() - start

    start = time.time()
    for key in delete_keys:
        bst.root = bst.delete(bst.root, key)
    bst_delete = time.time() - start

    # ---------- AVL ----------
    avl = AVLTree()
    start = time.time()
    for name in names:
        avl.root = avl.insert(avl.root, name)
    avl_insert = time.time() - start

    start = time.time()
    for key in search_keys:
        avl.search(avl.root, key)
    avl_search = time.time() - start

    start = time.time()
    for key in delete_keys:
        avl.root = avl.delete(avl.root, key)
    avl_delete = time.time() - start

    # ---------- RB ----------
    rb = RedBlackTree()
    start = time.time()
    for name in names:
        rb.insert(name)
    rb_insert = time.time() - start

    start = time.time()
    for key in search_keys:
        rb.search(rb.root, key)
    rb_search = time.time() - start

    rb_delete = 0  # skipped

    return {
        "BST": (bst_insert, bst_search, bst_delete),
        "AVL": (avl_insert, avl_search, avl_delete),
        "RB": (rb_insert, rb_search, rb_delete)
    }


# =========================
# GUI
# =========================
class App:
    def __init__(self, root):
        self.root = root
        root.title("Tree Benchmark")

        tk.Button(root, text="Run Benchmark", command=self.run).pack()
        self.text = tk.Text(root, height=15)
        self.text.pack()

    def run(self):
        results = benchmark()

        for tree in results:
            ins, sea, dele = results[tree]
            self.text.insert(tk.END,
                f"\n{tree}\nInsert: {ins:.6f}\nSearch: {sea:.6f}\nDelete: {dele:.6f}\n"
            )


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()