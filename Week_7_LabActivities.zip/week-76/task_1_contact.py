class Contact:
  def __init__(self, name, phone):
    self.name = name
    self.phone = phone
    self.left = None
    self.right = None