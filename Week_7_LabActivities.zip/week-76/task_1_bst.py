
from collections import deque
class Node:
  def __init__(self, value):
    self.value = value
    self.left = None
    self.right = None

  # Pre order transferal Method
  def preorder(root):
    if root:
      print(root.value, end=' ')
      preorder(root.left)
      preorder(root.right)

  # Inorder transferal method 
  def inorder(root):
    if root:
      inorder(root.left)
      print(root.value, end=' ')
      inorder(root.right)


  # Post Order transfer method
  def postorder(root):
    if root:
      postorder(root.left)
      postorder(root.right)
      print(root.value, end=' ')

  # Method for counting nodes
  def count_nodes(root):
    if root is None:
      return 0
    return 1 + count_nodes(root.left) + count_nodes(root.right)
  
  #Method to find height of the binary tree 
  def height(root):
    if root is None:
      return 0
    return 1 + max(height(root.left), height(root.right))
  
  #Method to find the values in Binary Search Tree
  def search_bst(root, val):
    if root is None or root.value == val:
      return root
    if val < root.value:
      return search_bst(root.left, val)
    else:
      return search_bst(root.right, val)
    
  # Method for inserting in the binary tree

  def insert_bst(root, val):
    if root is None:
      return Node(val)
    if val < root.value:
      root.left = insert_bst(root.left, val)
    else:
      root.right = insert_bst(root.right, val)
    return root
  
  # Method to find minimum value in the node 
  def find_min(root):
    current = root
    while current.left:
      current = current.left
    return current
  
  # Method to delete the value in the node
  def delete_node(root, val):
    if root is None:
      return root
    if val < root.value:
      root.left = delete_node(root.left, val)
    elif val > root.value:
      root.right = delete_node(root.right, val)
    else:
      # Node with 1 or no child
      if root.left is None:
        return root.right
      elif root.right is None:
        return root.left
      # Node with two children
      temp = find_min(root.right)
      root.value = temp.value
      root.right = delete_node(root.right, temp.value)

    return root
  
  # Method for transveral and navigation
  def level_order(root):
    if not root:
      return
    queue = deque([root])
    while queue:
      node = queue.popleft()
      print(node.value, end=' ')
      if node.left:
        queue.append(node.left)
      if node.right:
        queue.append(node.right)
# Example: create root node
root = Node(10)
root.left = Node(5)
root.right = Node(15)