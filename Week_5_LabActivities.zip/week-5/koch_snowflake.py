from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        self.width = 300
        self.height = 300

        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        frame = Frame(window)
        frame.pack()

        Label(frame, text="Enter an order: ").pack(side=LEFT)

        self.order = StringVar()
        Entry(frame, textvariable=self.order, width=5).pack(side=LEFT)

        Button(frame, text="Display koch snowflakes", command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("all")

        order = int(self.order.get())

        # Triangle points
        p1 = (50, 200)
        p2 = (250, 200)
        p3 = (150, 50)

        self.koch(p1, p2, order)
        self.koch(p2, p3, order)
        self.koch(p3, p1, order)

    def koch(self, p1, p2, order):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1])
        else:
            x1, y1 = p1
            x5, y5 = p2

            # Divide line into 3 parts
            x2 = x1 + (x5 - x1) / 3
            y2 = y1 + (y5 - y1) / 3

            x4 = x1 + 2 * (x5 - x1) / 3
            y4 = y1 + 2 * (y5 - y1) / 3

            # Create peak point
            angle = math.radians(60)
            x3 = x2 + (x4 - x2) * math.cos(angle) - (y4 - y2) * math.sin(angle)
            y3 = y2 + (x4 - x2) * math.sin(angle) + (y4 - y2) * math.cos(angle)

            # Recursive calls
            self.koch((x1, y1), (x2, y2), order - 1)
            self.koch((x2, y2), (x3, y3), order - 1)
            self.koch((x3, y3), (x4, y4), order - 1)
            self.koch((x4, y4), (x5, y5), order - 1)


# Run
KochSnowflake()