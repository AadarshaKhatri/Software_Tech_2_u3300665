import random
import timeit

# Function to get the sum of N numbers
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case


def sum_of_natural_numbers_iterations(n):
    total = 0
    for i in range (1,n+1):
        total = i+total
    return total

# Function to get the nth number from Fibonacci Series
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

def fibonacci_iterative(n):
    if n==1:
        return 0
    elif n==2:
        return 1
    
    a = 0 
    b = 1 
    for i in range(3,n+1):
        temp = a
        a = b 
        b = temp+b 
    return b
    
# Function to get the factorial of Nth number
def factorial(n):
    
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

def factorial_iterative(n):
    result = 1
    for i in range(1,n+1):
        result *= i
    return result
    





n = 99
n_fib = 20
n_fact = 15

sum_of_iteration = timeit.timeit(lambda: sum_of_natural_numbers_iterations(n),number=100 )
sum_of_recursion = timeit.timeit(lambda: sum_of_natural_numbers(n),number=100)

fibonacci_time = timeit.timeit(lambda: fibonacci(n_fib),number=100)
fibonacci_iteration_time = timeit.timeit(lambda:fibonacci_iterative(n_fib),number=100)

factorial_time = timeit.timeit(lambda : factorial(n_fact),number=100)
factorial_iterative_time = timeit.timeit(lambda: factorial_iterative(n_fact),number=100)

print(f"Sum of number through Iteration took: {sum_of_iteration:.6f} seconds")
print(f"Sum of number through Recursion took: {sum_of_recursion:.6f} seconds")

print()

print(f"Fibonacci through Iteration took: {fibonacci_iteration_time:.6f} seconds")
print(f"Fibonacci through Recursion took: {fibonacci_time:.6f} seconds")

print()

print(f"Facotrial through Iteration took: {factorial_iterative_time:.6f} seconds")
print(f"Facotrial through Recursion took: {factorial_time:.6f} seconds")

