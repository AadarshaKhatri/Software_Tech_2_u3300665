moves = 0 
def main():
  n = eval(input("Enter number of disks: "))
  # Find the solution recursively
  moves = moveDisks(n, 'A', 'B', 'C')
  print(f"The total number of moves required is {moves}")


# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
  global moves

  if n == 1: # Stopping condition
    print("Move disk", n, "from", fromTower, "to", toTower)
    moves = moves+1
  else:
    moveDisks(n - 1, fromTower, auxTower, toTower)
    print("Move disk", n, "from", fromTower, "to", toTower)
    moves+=1
    moveDisks(n - 1, auxTower, toTower, fromTower)
  return moves
  



if __name__ == "__main__":
  main()